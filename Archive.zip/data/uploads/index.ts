import auth from "./auth.json";
import common from "./common.json";
import updatePassword from "./update-password.json";

export default {
  auth,
  common,
  updatePassword,
};
