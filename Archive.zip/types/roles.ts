import { Permission, Role } from "@/lib/generated/prisma";

export type RoleWithPermissions = Role & {
  permissions: Permission[];
};
