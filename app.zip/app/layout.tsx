import type React from "react";
import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import { SidebarProvider } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/app-sidebar";
import { getSessionUser } from "@/lib/auth/getUserSession";
import { getUserPermissions } from "@/lib/auth/getUserPermissions";
import { redirect } from "next/navigation";
import { PERMISSIONS } from "@/lib/constants/permissions";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "Archive Management System",
  description:
    "Système de gestion d'archives avec authentification et permissions",
};

export default async function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const user = await getSessionUser();
  if(!user) redirect("/login")
  const permissions = user && getUserPermissions(user);
  if (permissions.includes("*")) {
    redirect("/dashboard");
  }

  if (
    permissions.includes("*") ||
    permissions.includes(PERMISSIONS.SUPER_ADMIN) ||
    permissions.includes(PERMISSIONS.DASHBOARD_VIEW)
  ) {
    redirect("/dashboard");
  }

  redirect("/dashboard/files");

  return (
    <html lang="fr">
      <body className={inter.className}>
        <SidebarProvider>
          <AppSidebar permissions={permissions} />
          <main className="flex-1">{children}</main>
        </SidebarProvider>
      </body>
    </html>
  );
}
